--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: m; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA m;


ALTER SCHEMA m OWNER TO postgres;

SET search_path = m, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: files; Type: TABLE; Schema: m; Owner: postgres; Tablespace: 
--

CREATE TABLE files (
    idfile bigint NOT NULL,
    md5 character varying(32),
    path character varying(250),
    filename character varying(250),
    note text,
    mimetype character varying(20),
    size integer,
    dt timestamp without time zone
);


ALTER TABLE files OWNER TO postgres;

--
-- Name: files_idfile_seq; Type: SEQUENCE; Schema: m; Owner: postgres
--

CREATE SEQUENCE files_idfile_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE files_idfile_seq OWNER TO postgres;

--
-- Name: files_idfile_seq; Type: SEQUENCE OWNED BY; Schema: m; Owner: postgres
--

ALTER SEQUENCE files_idfile_seq OWNED BY files.idfile;


--
-- Name: gallery; Type: TABLE; Schema: m; Owner: postgres; Tablespace: 
--

CREATE TABLE gallery (
    idgallery bigint NOT NULL,
    title character varying(250),
    note text,
    enabled boolean,
    dt timestamp without time zone
);


ALTER TABLE gallery OWNER TO postgres;

--
-- Name: gallery2files; Type: TABLE; Schema: m; Owner: postgres; Tablespace: 
--

CREATE TABLE gallery2files (
    idgallery bigint NOT NULL,
    idfile bigint NOT NULL
);


ALTER TABLE gallery2files OWNER TO postgres;

--
-- Name: gallery2files2files; Type: TABLE; Schema: m; Owner: postgres; Tablespace: 
--

CREATE TABLE gallery2files2files (
    idgallery bigint NOT NULL,
    idfile bigint NOT NULL
);


ALTER TABLE gallery2files2files OWNER TO postgres;

--
-- Name: gallery_idgallery_seq; Type: SEQUENCE; Schema: m; Owner: postgres
--

CREATE SEQUENCE gallery_idgallery_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gallery_idgallery_seq OWNER TO postgres;

--
-- Name: gallery_idgallery_seq; Type: SEQUENCE OWNED BY; Schema: m; Owner: postgres
--

ALTER SEQUENCE gallery_idgallery_seq OWNED BY gallery.idgallery;


--
-- Name: steads; Type: TABLE; Schema: m; Owner: postgres; Tablespace: 
--

CREATE TABLE steads (
    idstead bigint NOT NULL,
    pp integer,
    cadastr character varying(20),
    s integer,
    groupnum integer,
    status character varying(20),
    start character varying(100),
    points character varying(400)
);


ALTER TABLE steads OWNER TO postgres;

--
-- Name: steads_idstead_seq; Type: SEQUENCE; Schema: m; Owner: postgres
--

CREATE SEQUENCE steads_idstead_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE steads_idstead_seq OWNER TO postgres;

--
-- Name: steads_idstead_seq; Type: SEQUENCE OWNED BY; Schema: m; Owner: postgres
--

ALTER SEQUENCE steads_idstead_seq OWNED BY steads.idstead;


--
-- Name: users; Type: TABLE; Schema: m; Owner: postgres; Tablespace: 
--

CREATE TABLE users (
    iduser bigint NOT NULL,
    username character varying(50),
    md5pass character varying(32),
    id bigint,
    enabled boolean,
    dt timestamp without time zone,
    provider character varying(20),
    rights integer
);


ALTER TABLE users OWNER TO postgres;

--
-- Name: users_iduser_seq; Type: SEQUENCE; Schema: m; Owner: postgres
--

CREATE SEQUENCE users_iduser_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_iduser_seq OWNER TO postgres;

--
-- Name: users_iduser_seq; Type: SEQUENCE OWNED BY; Schema: m; Owner: postgres
--

ALTER SEQUENCE users_iduser_seq OWNED BY users.iduser;


--
-- Name: idfile; Type: DEFAULT; Schema: m; Owner: postgres
--

ALTER TABLE ONLY files ALTER COLUMN idfile SET DEFAULT nextval('files_idfile_seq'::regclass);


--
-- Name: idgallery; Type: DEFAULT; Schema: m; Owner: postgres
--

ALTER TABLE ONLY gallery ALTER COLUMN idgallery SET DEFAULT nextval('gallery_idgallery_seq'::regclass);


--
-- Name: idstead; Type: DEFAULT; Schema: m; Owner: postgres
--

ALTER TABLE ONLY steads ALTER COLUMN idstead SET DEFAULT nextval('steads_idstead_seq'::regclass);


--
-- Name: iduser; Type: DEFAULT; Schema: m; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN iduser SET DEFAULT nextval('users_iduser_seq'::regclass);


--
-- Data for Name: files; Type: TABLE DATA; Schema: m; Owner: postgres
--

COPY files (idfile, md5, path, filename, note, mimetype, size, dt) FROM stdin;
\.


--
-- Name: files_idfile_seq; Type: SEQUENCE SET; Schema: m; Owner: postgres
--

SELECT pg_catalog.setval('files_idfile_seq', 1, false);


--
-- Data for Name: gallery; Type: TABLE DATA; Schema: m; Owner: postgres
--

COPY gallery (idgallery, title, note, enabled, dt) FROM stdin;
1	--==новая галерея==--	<p>y77</p>	f	2016-10-20 00:13:58.829584
\.


--
-- Data for Name: gallery2files; Type: TABLE DATA; Schema: m; Owner: postgres
--

COPY gallery2files (idgallery, idfile) FROM stdin;
\.


--
-- Data for Name: gallery2files2files; Type: TABLE DATA; Schema: m; Owner: postgres
--

COPY gallery2files2files (idgallery, idfile) FROM stdin;
\.


--
-- Name: gallery_idgallery_seq; Type: SEQUENCE SET; Schema: m; Owner: postgres
--

SELECT pg_catalog.setval('gallery_idgallery_seq', 1, true);


--
-- Data for Name: steads; Type: TABLE DATA; Schema: m; Owner: postgres
--

COPY steads (idstead, pp, cadastr, s, groupnum, status, start, points) FROM stdin;
28	28	27:17:0329001:3490	1000	2	free	832.08821,1259.5747	85.21624,49.1996 -79.61857,137.9034 -85.21623,-49.1996
8	8	27:17:0329001:3470	1000	1	free	54.137862,1051.5625	158.752758,0 0,97.9403 -158.752758,0
18	18	27:17:0329001:3478	1000	2	free	268.35937,556.25	158.80493,0 0.49329,100.22856 -159.76562,0
29	29	27:17:0329001:3491	1000	2	free	917.30445,1308.7743	85.82765,49.5527 -79.61852,137.9034 -85.8277,-49.5527
9	9	27:17:0329001:3471	1276	1	free	54.137862,1149.5028	158.752738,0 69.12223,39.9077 -59.23688,102.6013 -168.638088,-97.3632
30	30	27:17:0329001:3492	1000	2	free	1003.1321,1358.327	86.651,50.0279 -79.6186,137.9034 -86.65092,-50.0279
4	4	27:17:0329001:3466	1000	1	free	54.137862,656.25	158.752758,0 0,99.6047 -158.752758,0
31	31	27:17:0329001:3493	1000	2	free	1089.7831,1408.3549	87.6289,50.5926 -79.6186,137.9034 -87.6289,-50.5926
39	39	27:17:0329001:3501	1219	3	free	427.1643,1025.7918	161.44684,-93.21137 68.13381,39.33704 -80.72343,139.81713
40	40	27:17:0329001:3502	1000	3	free	656.74495,971.91747	83.39468,48.14793 -80.72344,139.8171 -83.39467,-48.1479
41	41	27:17:0329001:3503	1000	3	free	740.13963,1020.0654	85.28147,49.2373 -80.72343,139.8171 -85.28148,-49.2373
19	19	27:17:0329001:3481	1000	2	free	267.88655,656.46772	159.74836,-0.0345 -0.17263,99.45942 -159.57031,0
42	42	27:17:0329001:3504	1000	3	free	825.4211,1069.3027	87.39055,50.4549 -80.72344,139.8171 -87.39054,-50.4549
22	22	27:17:0329001:3484	1204	2	free	267.69665,952.57231	159.46765,-0.22851 0,73.448 -159.23712,91.9356
23	23	27:17:0329001:3485	1156	2	free	427.1643,1025.7918	58.58519,33.8242 -79.61857,137.9034 -138.20374,-79.792
24	24	27:17:0329001:3486	1000	2	free	485.74949,1059.616	90.27203,52.1186 -79.61857,137.9034 -90.27203,-52.1186
25	25	27:17:0329001:3487	1000	2	free	576.02152,1111.7346	83.39467,48.1479 -79.61856,137.9034 -83.39468,-48.1479
26	26	27:17:0329001:3488	1000	2	free	659.41619,1159.8825	85.28148,49.2373 -79.61857,137.9034 -85.28147,-49.2373
27	27	27:17:0329001:3489	1000	2	free	744.69767,1209.1198	87.39054,50.4549 -79.61856,137.9034 -87.39055,-50.4549
10	10	27:17:0329001:3472	1200	1	free	282.01283,1189.4105	138.83559,80.1568 -59.23689,102.6013 -138.83558,-80.1568
32	32	27:17:0329001:3494	1028	2	free	1177.412,1458.9475	93.0593,53.7278 -96.5509,128.1275 -76.127,-43.9519
33	33	27:17:0329001:3495	843	3	free	427.1643,375.586	161.44684,0 0,80.2734 -161.44684,0 0,-80.2734
34	34	27:17:0329001:3496	1000	3	free	427.1643,455.8594	161.44684,0 0,100.3906 -161.44684,0
35	35	27:17:0329001:3497	1000	3	free	427.1643,556.25	161.44684,0 0,100 -161.44684,0
36	36	27:17:0329001:3498	1000	3	free	427.1643,656.25	161.44684,0 0,99.6047 -161.44684,0
37	37	27:17:0329001:3499	1000	3	free	427.1643,755.8547	161.44684,0 0,98.0516 -161.44684,0
11	11	27:17:0329001:3473	1200	1	free	420.8466,1269.1957	131.43274,76.2533 -59.23689,102.6013 -131.43092,-75.8817
43	43	27:17:0329001:3505	1000	3	free	912.81165,1119.7576	85.21623,49.1997 -80.72343,139.817 -85.21624,-49.1996
1	1	27:17:0329001:3463	827	1	free	54.137862,375.586	158.984378,0 -0.19532,80.8594 -158.752759,0
2	2	27:17:0329001:3464	1000	1	free	54.137862,455.8594	158.752758,0 0,100.3906 -158.752758,0
12	12	27:17:0329001:3474	1200	1	free	552.27934,1345.449	144.51199,83.434 -59.23688,102.6013 -144.512,-83.434
3	3	27:17:0329001:3465	1000	1	free	54.137862,556.25	158.752758,0 0,100 -158.752758,0
13	13	27:17:0329001:3475	1200	1	free	696.79133,1428.883	138.46261,79.9414 -59.23689,102.6013 -138.4626,-79.9414
14	14	27:17:0329001:3476	1270	1	free	835.25394,1508.8244	147.39231,85.097 -59.23688,102.6013 -147.39232,-85.097
16	16	27:17:0329001:3479	836	2	free	267.92717,375.586	159.23713,0 0,80.2734 -158.80493,0
17	17	27:17:0329001:3480	1000	2	free	268.35937,455.8594	158.80493,0 0,100.3906 -158.80493,0
38	38	27:17:0329001:3500	1267	3	free	427.1643,853.9063	161.44684,0 2e-5,78.67411 -161.44686,93.21139
5	5	27:17:0329001:3467	1000	1	free	54.137862,755.8547	158.752758,0 0,98.0516 -158.752758,0
6	6	27:17:0329001:3468	1000	1	free	54.137862,853.9063	158.752758,0 0,98.4375 -158.752758,0
7	7	27:17:0329001:3469	1000	1	free	54.137862,952.3438	158.752758,0 0,99.2187 -158.752758,0
20	20	27:17:0329001:3482	1000	2	free	267.84661,755.69731	159.31769,0.15739 0,98.0516 -159.27233,-0.35743
15	15	27:17:0329001:3477	1890	1	free	982.64625,1593.9214	157.90355,91.1657 -124.1436,164.7441 -92.99683,-153.3085
21	21	27:17:0329001:3483	1000	2	free	267.89197,853.35356	159.27233,0.55274 0,98.4375 -159.46765,0.42382
44	44	27:17:0329001:3506	1000	3	free	998.02788,1168.9573	85.82772,49.5526 -80.7235,139.8171 -85.82765,-49.5527
45	45	27:17:0329001:3507	1000	3	free	1083.8556,1218.5099	86.6509,50.028 -80.7234,139.817 -86.651,-50.0279
46	46	27:17:0329001:3508	1000	3	free	1170.5065,1268.5379	87.6289,50.5925 -80.7234,139.8171 -87.6289,-50.5926
47	47	27:17:0329001:3509	1243	3	free	1258.1354,1319.1304	110.2267,63.6395 -97.8908,129.9054 -93.0593,-53.7278
48	48	27:17:0329001:3510	852	4	free	641.36793,375.586	160.35527,0 0,80.2734 -160.35527,0
49	49	27:17:0329001:3511	1000	4	free	641.36793,455.8594	160.35527,0 0,100.3906 -160.35527,0
50	50	27:17:0329001:3512	1000	4	free	641.36793,556.25	160.35527,0 0,100 -160.35527,0
51	51	27:17:0329001:3513	1000	4	free	641.36793,656.25	160.35527,0 0,99.6047 -160.35527,0
52	52	27:17:0329001:3514	1001	4	free	641.36793,755.8547	160.35527,0 0,53.68542 -160.35527,92.58118
53	53	27:17:0329001:3515	952	4	free	641.36793,902.1213	160.35527000000002,-92.58118000000002 44.972440000000006,25.964849999999956 -80.17764,138.87176
54	54	27:17:0329001:3516	1000	4	free	846.69564,835.50497	85.28147999999999,49.23729000000003 -80.17764999999997,138.87174000000005 -85.28147000000001,-49.23727000000008
55	55	27:17:0329001:3517	1000	4	free	931.97712,884.74226	87.39058,50.45495 -80.17768,138.87179 -87.39055,-50.455
56	56	27:17:0329001:3518	1000	4	free	1019.3677,935.19721	85.2162,49.19962 -80.1776,138.87177 -85.21628,-49.1996
57	57	27:17:0329001:3519	1000	4	free	1104.5839,984.39683	85.8277,49.55267 -80.1776,138.8717 -85.8277,-49.5526
58	58	27:17:0329001:3520	1000	4	free	1190.4116,1033.9495	86.651,50.0279 -80.1777,138.8718 -86.6509,-50.028
59	59	27:17:0329001:3521	1000	4	free	1277.0626,1083.9774	87.6288,50.5926 -80.1776,138.8717 -87.6289,-50.5925
60	60	27:17:0329001:3522	1100	4	free	1347.2888,1164.7122	129.1869,74.5861 -76.1253,101.0217 -115.8366,-66.8783
61	61	27:17:0329001:3525	858	5	free	801.7232,375.586	158.91259,0 0,80.2734 -158.91259,0
62	62	27:17:0329001:3526	1000	5	free	801.7232,455.8594	158.91259,0 0,100.3906 -158.91259,0
63	63	27:17:0329001:3527	1000	5	free	801.7232,556.25	158.91259,0 0,100 -158.91259,0
64	64	27:17:0329001:3528	1065	5	free	801.7232,656.25	158.91259,0 0,61.5419 -158.91259,91.74822
65	65	27:17:0329001:3529	1016	5	free	960.63579,717.7919	50.79760999999996,29.328019999999924 -79.45627999999999,137.62234 -130.25392,-75.20213999999999
66	66	27:17:0329001:3530	1000	5	free	1011.4334,747.11992	87.3906,50.45495 -79.4563,137.62234 -87.39058,-50.45495
67	67	27:17:0329001:3531	1000	5	free	1098.824,797.57487	85.2162,49.19962 -79.4563,137.62234 -85.2162,-49.19962
68	68	27:17:0329001:3532	1000	5	free	1184.0402,846.77449	85.8277,49.55264 -79.4563,137.62237 -85.8277,-49.55267
69	69	27:17:0329001:3533	1000	5	free	1269.8679,896.32713	86.651,50.02796 -79.4563,137.62231 -86.651,-50.0279
70	70	27:17:0329001:3534	1000	5	free	1356.5189,946.35509	87.6288,50.59255 -79.4563,137.62236 -87.6288,-50.5926
71	71	27:17:0329001:3523	1083	5	free	1399.5596,1074.1765	140.3033,81.0042 -63.3872,84.1176 -129.1869,-74.5861
72	72	27:17:0329001:3524	1100	5	free	1444.1477,996.94764	149.7858,86.47886 -54.0706,71.7542 -140.3033,-81.0042
\.


--
-- Name: steads_idstead_seq; Type: SEQUENCE SET; Schema: m; Owner: postgres
--

SELECT pg_catalog.setval('steads_idstead_seq', 72, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: m; Owner: postgres
--

COPY users (iduser, username, md5pass, id, enabled, dt, provider, rights) FROM stdin;
1	admin	f6fdffe48c908deb0f4c3bd36c032e72	1	t	2016-09-28 21:39:12.509191	mc	7
2	serg	e0e581846e613fb1beadc89c885ba0fa	\N	t	2016-09-28 21:39:12.511364	mc	31
\.


--
-- Name: users_iduser_seq; Type: SEQUENCE SET; Schema: m; Owner: postgres
--

SELECT pg_catalog.setval('users_iduser_seq', 2, true);


--
-- Name: files_pkey; Type: CONSTRAINT; Schema: m; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY files
    ADD CONSTRAINT files_pkey PRIMARY KEY (idfile);


--
-- Name: gallery_pkey; Type: CONSTRAINT; Schema: m; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY gallery
    ADD CONSTRAINT gallery_pkey PRIMARY KEY (idgallery);


--
-- Name: galleryfile_pkey; Type: CONSTRAINT; Schema: m; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY gallery2files
    ADD CONSTRAINT galleryfile_pkey PRIMARY KEY (idgallery, idfile);


--
-- Name: unit_pkey; Type: CONSTRAINT; Schema: m; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT unit_pkey PRIMARY KEY (iduser);


--
-- Name: gallery2files_idfile; Type: INDEX; Schema: m; Owner: postgres; Tablespace: 
--

CREATE INDEX gallery2files_idfile ON gallery2files USING btree (idfile);


--
-- Name: gallery2files_idgallery; Type: INDEX; Schema: m; Owner: postgres; Tablespace: 
--

CREATE INDEX gallery2files_idgallery ON gallery2files USING btree (idgallery);


--
-- Name: constr_gallery2files_files; Type: FK CONSTRAINT; Schema: m; Owner: postgres
--

ALTER TABLE ONLY gallery2files
    ADD CONSTRAINT constr_gallery2files_files FOREIGN KEY (idfile) REFERENCES files(idfile) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: constr_gallery2files_gallery; Type: FK CONSTRAINT; Schema: m; Owner: postgres
--

ALTER TABLE ONLY gallery2files
    ADD CONSTRAINT constr_gallery2files_gallery FOREIGN KEY (idgallery) REFERENCES gallery(idgallery) MATCH FULL ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: m; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA m FROM PUBLIC;
REVOKE ALL ON SCHEMA m FROM postgres;
GRANT ALL ON SCHEMA m TO postgres;
GRANT ALL ON SCHEMA m TO site;


--
-- Name: files; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON TABLE files FROM PUBLIC;
REVOKE ALL ON TABLE files FROM postgres;
GRANT ALL ON TABLE files TO postgres;
GRANT ALL ON TABLE files TO site;


--
-- Name: files_idfile_seq; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON SEQUENCE files_idfile_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE files_idfile_seq FROM postgres;
GRANT ALL ON SEQUENCE files_idfile_seq TO postgres;
GRANT ALL ON SEQUENCE files_idfile_seq TO site;


--
-- Name: gallery; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON TABLE gallery FROM PUBLIC;
REVOKE ALL ON TABLE gallery FROM postgres;
GRANT ALL ON TABLE gallery TO postgres;
GRANT ALL ON TABLE gallery TO site;


--
-- Name: gallery2files; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON TABLE gallery2files FROM PUBLIC;
REVOKE ALL ON TABLE gallery2files FROM postgres;
GRANT ALL ON TABLE gallery2files TO postgres;
GRANT ALL ON TABLE gallery2files TO site;


--
-- Name: gallery_idgallery_seq; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON SEQUENCE gallery_idgallery_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE gallery_idgallery_seq FROM postgres;
GRANT ALL ON SEQUENCE gallery_idgallery_seq TO postgres;
GRANT ALL ON SEQUENCE gallery_idgallery_seq TO site;


--
-- Name: steads; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON TABLE steads FROM PUBLIC;
REVOKE ALL ON TABLE steads FROM postgres;
GRANT ALL ON TABLE steads TO postgres;
GRANT ALL ON TABLE steads TO site;


--
-- Name: steads_idstead_seq; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON SEQUENCE steads_idstead_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE steads_idstead_seq FROM postgres;
GRANT ALL ON SEQUENCE steads_idstead_seq TO postgres;
GRANT ALL ON SEQUENCE steads_idstead_seq TO site;


--
-- Name: users; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON TABLE users FROM PUBLIC;
REVOKE ALL ON TABLE users FROM postgres;
GRANT ALL ON TABLE users TO postgres;
GRANT ALL ON TABLE users TO site;


--
-- Name: users_iduser_seq; Type: ACL; Schema: m; Owner: postgres
--

REVOKE ALL ON SEQUENCE users_iduser_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE users_iduser_seq FROM postgres;
GRANT ALL ON SEQUENCE users_iduser_seq TO postgres;
GRANT ALL ON SEQUENCE users_iduser_seq TO site;


--
-- PostgreSQL database dump complete
--

